# COACH SAMMY — HANDOFF / CONTINUATION DOC
_Everything pending, in-flight, and parked. Hand this to the next chat so nothing is lost._

---

## 0. HOW WE WORK (the loop — never break it)
- App = ONE big HTML file: `coach_sammy_v7 (2).html` (~42,600+ lines). Single file, Supabase backend, vanilla JS.
- Deployed at **coachsammyapp.tiiny.site** via tiiny.host — **caches HARD, always test in a fresh incognito window.**
- Edit loop: Claude inspects the real file (bash/grep/view) → writes ONE find/replace prompt as a **single plain code block** (not blockquoted, no weird symbols) → Sammy runs it in a **separate Claude Code instance** on his Mac → re-uploads the file → Claude verifies marker present + `node --check` passes on the big inline script.
- Every change gets a unique MARKER comment (e.g. `/* MARKER: FEATURE_V1 */`) so we can grep-verify it landed.
- Single-line replacements land more reliably than multi-line blocks in Claude Code. French accents paste fine.
- Sammy moves fast, communicates tersely (often voice-to-text), wants BOLD visible change.

## KEY TECHNICAL FACTS
- Supabase project: `korektlpnwuefsagfuvq` · URL `https://korektlpnwuefsagfuvq.supabase.co`
- Local Mac project: `/Users/mac/Downloads/coach-sammy/`
- Coach login pw `sammy2024` · WhatsApp `213698103835` · email `skyerr7@gmail.com`
- Globals: Supabase client = `sb` (single client, line ~34202). Roster = `coachClients[]`. Client profile state = `_cpState`. Client object = `CC`. Client goals = `CG`.
- `--gold`/`--g` CSS vars are actually BLUE `#4EA8DE`. Real gold = `#d4af37` via `btn-gold`. Accent green `#4ade80`, red `#fb7185`.
- Cookbook: table `cookbook_recipes` (const `COOKBOOK_TABLE`), **414 recipes confirmed**, loaded into global `COOKBOOK_RECIPES[]` via `loadCookbook()` (~line 8140). RLS has `public_read` policy (SELECT, anon, true) — reads work for all roles (verified 414 as both postgres and authenticated). Recipe fields: `total_calories, total_protein, total_carbs, total_fat, title, category, cuisine, servings, featured, craving_tag, id, photo_url`. NO meal-slot field (no breakfast/lunch/dinner tag) — only category/cuisine. Cuisine keys: all/algerian/italian/asian/texmex/mediterranean/indian/american/french/african.
- Client menus stored in `meal_plans` table, `plan_data` JSONB = `{days:[{day,meals:[{name,title,recipe_id,foods:[{name,quantity,calories,protein,carbs,fat}],instructions}]}]}`. Client reads it at ~17453 / ~14832.
- Date helpers: `localISO(d)` (~9415) for log_date. BANNED for log_date: `new Date('YYYY-MM-DD')` and `.toISOString().slice(0,10)` (UTC shift). Selected journal day = `getDateWD(curWeek, curDayIdx)` (~10235). Globals `curWeek, curDayIdx` (~9389).

---

## 1. IN-FLIGHT RIGHT NOW (finish these first)

### 1a. Cookbook publish bug — FIX JUST SENT, needs verify
- Symptom: cookbook generator works + preview shows, but "Publier ce plan" does nothing — no menu saved.
- Fix in flight: marker `COOKBOOK_PUBLISH_FIX_V1` on `publishCookbookPlan` — makes insert loud (surfaces RLS/schema errors via `.select()` + error code) instead of failing silently, guards null `_cbGenerated`/`clientId`.
- NEXT: verify marker landed + parses. Then Sammy tests publish. If it now shows an error, READ IT — likely RLS on `meal_plans` INSERT (the SELECT policy exists but INSERT policy may not for the coach context) OR a required column. If RLS: add an insert policy on `meal_plans`. Compare to the working insert at line ~32809 (`runGenMealPlan` inserts successfully — the 2369kcal plan published that way), so the difference is isolated to this function/path.

### 1b. Cookbook generator load — WORKING via global-reuse
- `COOKBOOK_DIAG_V1` marker on `generateCookbookMealPlan`: now uses already-loaded `COOKBOOK_RECIPES` global first, only queries fresh if empty. The fresh `sb.from(COOKBOOK_TABLE).select('*')` was returning empty in coach-viewing-client context (DB is fine — 414 rows, reads open; cause was client-side context, never fully root-caused but global-reuse sidesteps it).
- WORKAROUND Sammy uses: open Tools > Cookbook once first (fills the global), then generate. CONSIDER: make generator auto-load reliably so this step isn't needed — investigate why the fresh query returns [] in that context (possibly `sb` not ready, or a stale query-builder state).

### 1c. Mobile toggle polish — prompt sent, may need verify
- `COOKBOOK_TOGGLE_MOBILE_V1` — tightens the IA/Cookbook radio pills on phone (radio snug next to label). Verify it landed if Sammy ran it.

---

## 2. EDGE FUNCTION — ai-coach (AI generators + Message IA)
- The AI-based meal generator ("Générer le plan" with Source=IA) AND "Message IA" both call Supabase edge function `ai-coach` at `{SUPABASE_URL}/functions/v1/ai-coach`.
- App calls via `callEdge(action,payload)` (~27443). Actions: `coach_message`, `meal_plan`, `convert_sessions`, `full_program`, `raw`.
- **STATUS: the updated edge function code (handles all 5 actions incl. `meal_plan`, correct text-vs-JSON responses, hits ±10% calorie target) is written and lives at `/mnt/user-data/outputs/ai-coach-index.ts`.** It was deployed earlier BUT an old 80-line version got deployed first because paste-into-Claude-Code failed twice. The corrected full version may or may not have deployed cleanly — VERIFY by testing Message IA / AI generate.
- DEPLOY METHOD (auth now cached, no re-login): in Claude Code paste the full `ai-coach-index.ts` content, then:
  ```
  cd /Users/mac/Downloads/coach-sammy
  npx --yes supabase functions deploy ai-coach --project-ref korektlpnwuefsagfuvq
  ```
  (brew NOT installed; use npx. Login was done via device-code browser flow, token cached at ~/.supabase.)
- If AI still errors after deploy, check Supabase > Edge Functions > ai-coach > Logs. The new function throws CLEAR errors:
  - `ANTHROPIC_API_KEY secret is not set` → add it: Edge Functions > ai-coach > Secrets, key from console.anthropic.com.
  - `Anthropic API 401` → key dead/invalid (Sammy's key was exposed in a past chat, may need rotating).
  - `Anthropic API 404` → model string issue, swap `claude-sonnet-4-20250514`.
- NOTE: never paste API keys/tokens into chat (Option A browser login only).

---

## 3. THE BIG PARKED PROJECT (Sammy emphasized — DO NOT FORGET)
**Cookbook content + images overhaul:**
1. **Add MORE recipes** to the cookbook (grow the 414 catalog). Recipes are added via `.mjs` seed scripts using the Supabase service role key, run from `/Users/mac/Downloads/coach-sammy/`. Past gotcha: `difficulty` column is INTEGER (1/2/3) not text — `'easy'/'medium'/'hard'` inserts fail. All recipes: halal-adapted, ingredients available in Algerian supermarkets (Carrefour, Ardis, Family Shop, Numidis), French with Arabic subtitle on description.
2. **FIX THE IMAGES** — this is the important one. Recipe images are RANDOM, not aligned with the actual meal. Need images that match each recipe. (`photo_url` field on `cookbook_recipes`.) Investigate: are they placeholder/wrong URLs? Need a proper image source/mapping per recipe.

---

## 4. SMALLER PENDING / CLEANUP
- **Bilan → EN + AR**: `BILAN_FR_V2` rewrote the FRENCH weekly report (personalized, week-over-week, in `generateWeeklyReport(clientId,lang)` ~24669, with `BILAN_LASTWEEK_V1` prev-week fetch). Port the same logic to the EN and AR paths once FR is confirmed good live.
- **Leftover compliance formulas**: shared truth is `dayCompliance(calAxis,stepAxis,trainAxis,isRestDay)` (`COMPLIANCE_CORE_V1` ~8990, training day 60/30/10, rest day 86/14, cal hit = within 15%). Still on OLD formulas: leaderboard (~20151), 30-day stat (~20123), worklist `last_compliance_score`. Point them at `dayCompliance`.
- **start_weight on real clients**: the Daily Rounds check-in card (`DR_CARD_V2`/`DR_LOADSTATS_V2`) shows weight CHANGE (↓3kg) only if client has `start_weight` set. Many may not. Consider: auto-capture first logged weight as start_weight, or a quick coach UI to set it.
- **Cookbook meal labels**: generator labels meals by calorie size (smallest→PETIT-DÉJEUNER). Since recipes lack meal-slot tags, a big-calorie breakfast recipe could get mislabeled. If it feels off with real data, quick tweak (or add a meal_type column to recipes — ties into the content overhaul).

---

## 5. DONE THIS SESSION (context — don't redo)
- **Glass redesign — all 5 coach screens** + Bureau "My day" hero (`BUREAU_MYDAY_GLASS_V1` + `BUREAU_MYDAY_HTML_V2`). Markers: CHECKINS_GLASS_V1, CLIENTS_GLASS_V1, WORKLIST_GLASS_V1, BUREAU_GLASS_V1, INSIGHTS_GLASS_V1, etc.
- **Daily Rounds check-in card rebuilt** (`DR_CARD_V2`, `DR_LOADSTATS_V2`): current weight + change vs start, target, full-period weight graph (reuses `_renderSparkline`), trained-vs-program, ate-clean, steps, last-seen. Mood/abstract-compliance removed. Card scroll fix (`DR_CARD_SCROLL_V1`, stack 560px) so it doesn't overlap the bottom swipe bar. AI msg modal z-fix (`AI_MSG_ZFIX_V1`, z-index 11000) + nudge modal z-index so they open ON TOP of Daily Rounds, not behind.
- **Compliance unified** (`COMPLIANCE_CORE_V1`, `COMPLIANCE_DAILY_V1`, `COMPLIANCE_CAL15_V1`, `COMPLIANCE_COACH_WEEKLY_V1`) — coach & client numbers now match.
- **Journal back-dating bugs FIXED** (`JOURNAL_BACKLOG_DATE_FIX_V1` on `saveTodayCheckin`, `JOURNAL_EDITOR_DATE_FIX_V1` on the full editor): back-logged check-ins AND manual macro/calorie edits now save to the SELECTED day, not today. Root was `toISO()` (today) instead of `getDateWD(curWeek,curDayIdx)`.
- **Win-back back-button** (`WINBACK_BACK_FIX_V1`) + segment filter row (`SEGMENT_ROW_FIX_V1`).
- **Coach-side Cookbook** (`COACH_COOKBOOK_V1`): Tools menu > Cookbook opens full-screen overlay reusing `renderKitchen` into `#kitchen-screen`, destroy-on-close to avoid dup IDs. All 414 browsable coach-side.
- **Cookbook meal-plan generator** (the big new feature): `_cbMatch` matcher + `generateCookbookMealPlan` (COOKBOOK_GEN_V1), dispatcher `runGenMealDispatch` + `publishCookbookPlan` (COOKBOOK_DISPATCH_V1), picker UI source/meals/cuisine (COOKBOOK_PICKER_V1), load robustness (COOKBOOK_LOAD_FIX_V1 → COOKBOOK_DIRECTLOAD_V1 → COOKBOOK_DIAG_V1). Pick Source (IA/Cookbook) + meals + cuisine, generates to ±10% of calorie target from real recipes, preview w/ % accuracy, regenerate, publish. GENERATION WORKS; publish fix in flight (§1a).

---

## 6. WHAT SAMMY WANTS NEXT (his words)
1. Finish meal-plan feature (publish bug) — §1a
2. Both AI + cookbook generators fully working — §1a/§2
3. **Add more recipes + FIX MISMATCHED IMAGES** — §3 (he stressed this repeatedly)
