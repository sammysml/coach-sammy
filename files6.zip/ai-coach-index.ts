// supabase/functions/ai-coach/index.ts
// Coach Sammy — AI edge function. Routes prompts to Claude and returns text or JSON.
//
// DEPLOY:
//   cd /Users/mac/Downloads/coach-sammy
//   npx --yes supabase functions deploy ai-coach --project-ref korektlpnwuefsagfuvq

import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const ANTHROPIC_API_KEY = Deno.env.get("ANTHROPIC_API_KEY");
const MODEL = "claude-sonnet-4-20250514";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

async function callClaude(system: string, user: string, maxTokens = 1024): Promise<string> {
  if (!ANTHROPIC_API_KEY) throw new Error("ANTHROPIC_API_KEY secret is not set on this function");
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: maxTokens,
      system: system || "You are a helpful assistant.",
      messages: [{ role: "user", content: user }],
    }),
  });
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Anthropic API ${res.status}: ${errText.slice(0, 300)}`);
  }
  const data = await res.json();
  const text = (data?.content || []).filter((b: any) => b.type === "text").map((b: any) => b.text).join("\n").trim();
  if (!text) throw new Error("Empty completion from Claude");
  return text;
}

// Strip ```json fences and parse
function parseJSON(text: string): any {
  const clean = text.replace(/```json/gi, "").replace(/```/g, "").trim();
  return JSON.parse(clean);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  try {
    const body = await req.json().catch(() => ({}));
    const action = body?.action || "raw";
    const payload = body?.payload || {};

    // ── meal_plan: build a nutrition plan JSON from macro targets ──
    if (action === "meal_plan") {
      const cal = payload?.calories || 2000;
      const prot = payload?.protein || 130;
      const carbs = payload?.carbs || 200;
      const fat = payload?.fat || 60;
      const goal = payload?.goal || "";
      const prefs = payload?.preferences || "";
      const excluded = payload?.excluded || "";
      const sys = "Tu es un nutritionniste. Tu reponds UNIQUEMENT en JSON valide, sans texte avant ou apres, sans backticks.";
      const user = `Cree un plan nutritionnel d'une journee pour un client.
Objectifs: ${cal} kcal, ${prot}g proteines, ${carbs}g glucides, ${fat}g lipides.
Objectif client: ${goal}. Preferences: ${prefs}. A exclure: ${excluded}.
Ingredients disponibles en Algerie, halal, simples.
Le total des calories doit etre a +/- 10% de ${cal} kcal.
Reponds en JSON exactement dans ce format:
{"days":[{"day":"Jour 1","meals":[{"name":"PETIT-DEJEUNER","title":"...","foods":[{"name":"...","quantity":"...","calories":0,"protein":0,"carbs":0,"fat":0}],"instructions":"..."}]}]}`;
      const text = await callClaude(sys, user, 3000);
      const json = parseJSON(text);
      return new Response(JSON.stringify({ data: json, ...json }), {
        headers: { ...cors, "content-type": "application/json" },
      });
    }

    // ── convert_sessions: structure a pasted plan into JSON ──
    if (action === "convert_sessions") {
      const prompt = payload?.prompt || payload?.text || "";
      if (!prompt) throw new Error("Missing payload.text");
      const sys = payload?.system || "Tu reponds UNIQUEMENT en JSON valide. Convertis le texte en plan structure.";
      const text = await callClaude(sys, prompt, 3000);
      let out: any;
      try { out = parseJSON(text); } catch { out = { text }; }
      return new Response(JSON.stringify({ data: out, ...(typeof out === "object" ? out : {}) }), {
        headers: { ...cors, "content-type": "application/json" },
      });
    }

    // ── coach_message: weekly WhatsApp message (plain text) ──
    if (action === "coach_message") {
      if (!payload?.prompt) throw new Error("Missing payload.prompt");
      const text = await callClaude("Tu es un coach sportif experimente qui ecrit des messages personnels a ses clients.", payload.prompt, 800);
      return new Response(text, { headers: { ...cors, "content-type": "text/plain" } });
    }

    // ── full_program: long-form (plain text) ──
    if (action === "full_program") {
      const prompt = payload?.prompt || payload?.user || "";
      if (!prompt) throw new Error("Missing payload.prompt");
      const text = await callClaude(payload?.system || "You are an expert fitness program designer.", prompt, 4000);
      return new Response(text, { headers: { ...cors, "content-type": "text/plain" } });
    }

    // ── raw / default: passthrough (plain text) ──
    {
      const system = payload?.system || "You are a helpful assistant.";
      const user = payload?.user || payload?.prompt || "";
      if (!user) throw new Error("Missing payload.user or payload.prompt");
      const text = await callClaude(system, user, payload?.maxTokens || 2000);
      return new Response(text, { headers: { ...cors, "content-type": "text/plain" } });
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("ai-coach error:", msg);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...cors, "content-type": "application/json" },
    });
  }
});
