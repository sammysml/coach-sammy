/* ═══════════════════════════════════════════════════════
   PHASE 7.5 — MACRO ENHANCEMENTS
   Exposes:
     window.macroProgressRender(clientId, el)    — client daily progress card
     window.macroAdherenceRender(clientId, el)   — coach weekly adherence heatmap
   Auto-refreshes on dayTypeChanged / mealLogged events.
   Requires Phase 7 (getTodayTargets).
   ═══════════════════════════════════════════════════════ */

(function(){
  'use strict';

  function _sb(){
    return window.sb || window.supabase || window._sb
        || (typeof sb !== 'undefined' ? sb : null)
        || (typeof supabase !== 'undefined' ? supabase : null);
  }

  const esc = s => String(s==null?'':s).replace(/[&<>"']/g,
    c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);

  const DAY_KEYS = ['sun','mon','tue','wed','thu','fri','sat'];
  const DAY_LABEL_SHORT = {mon:'L', tue:'M', wed:'M', thu:'J', fri:'V', sat:'S', sun:'D'};

  function todayBounds(){
    const start = new Date(); start.setHours(0,0,0,0);
    const end = new Date(start); end.setDate(end.getDate()+1);
    return {start: start.toISOString(), end: end.toISOString()};
  }

  function statusFor(actual, target){
    if(!target || target === 0) return 'no-data';
    const pct = actual / target;
    if(pct > 1.20) return 'over';
    return 'normal';
  }

  function adherenceStatusFor(actual, target){
    if(!target || target === 0) return 'no-data';
    if(actual === 0) return 'no-data';
    const pct = actual / target;
    if(pct >= 0.85 && pct <= 1.15) return 'hit';
    if((pct >= 0.70 && pct < 0.85) || (pct > 1.15 && pct <= 1.25)) return 'close';
    if(pct > 1.25 && pct <= 1.50) return 'over';
    return 'miss';
  }

  // ─── Data fetchers (defensive across column name variants) ───
  async function fetchMealsForRange(clientId, startISO, endISO){
    const sb = _sb(); if(!sb) return [];
    try {
      const q = sb.from('meal_entries')
        .select('calories, protein, carbs, fat, protein_g, carbs_g, fat_g, created_at')
        .eq('client_id', clientId)
        .gte('created_at', startISO);
      const res = endISO ? await q.lt('created_at', endISO) : await q;
      return res.data || [];
    } catch(e){ console.warn('[7.5] fetchMeals', e); return []; }
  }

  function sumMeals(meals){
    return meals.reduce((a, m) => ({
      calories: a.calories + (Number(m.calories) || 0),
      protein:  a.protein  + (Number(m.protein  ?? m.protein_g) || 0),
      carbs:    a.carbs    + (Number(m.carbs    ?? m.carbs_g)   || 0),
      fat:      a.fat      + (Number(m.fat      ?? m.fat_g)     || 0)
    }), {calories:0, protein:0, carbs:0, fat:0});
  }

  async function fetchClientGoal(clientId){
    const sb = _sb(); if(!sb) return null;
    try {
      const {data} = await sb.from('client_goals').select('*').eq('client_id', clientId).maybeSingle();
      return data;
    } catch(e){ return null; }
  }

  async function fetchSessionDaysLastWeek(clientId){
    const sb = _sb(); if(!sb) return new Set();
    const start = new Date(); start.setDate(start.getDate()-6); start.setHours(0,0,0,0);
    try {
      const {data} = await sb.from('exercise_logs')
        .select('completed_at, created_at')
        .eq('client_id', clientId)
        .gte('completed_at', start.toISOString());
      const days = new Set();
      (data||[]).forEach(l => {
        const d = new Date(l.completed_at || l.created_at);
        d.setHours(0,0,0,0);
        days.add(d.toDateString());
      });
      return days;
    } catch(e){ return new Set(); }
  }

  async function fetchOverridesLastWeek(clientId){
    const sb = _sb(); if(!sb) return {};
    const start = new Date(); start.setDate(start.getDate()-6);
    const startStr = start.toISOString().split('T')[0];
    try {
      const {data} = await sb.from('day_type_overrides')
        .select('date, day_type')
        .eq('client_id', clientId)
        .gte('date', startStr);
      const m = {};
      (data||[]).forEach(o => m[o.date] = o.day_type);
      return m;
    } catch(e){ return {}; }
  }

  // ═══════════════════════════════════════════════════════
  // CLIENT — Daily Macro Progress Card
  // ═══════════════════════════════════════════════════════
  window.macroProgressRender = async function(clientId, containerEl){
    if(!containerEl || !clientId) return;
    containerEl.dataset.macroProgress = '1';
    containerEl.dataset.clientId = clientId;

    if(typeof window.getTodayTargets !== 'function'){
      containerEl.innerHTML = '<div style="padding:14px;color:rgba(255,255,255,.4);font-size:12px">Phase 7 requis pour afficher la progression.</div>';
      return;
    }

    const {start, end} = todayBounds();
    const [targets, meals] = await Promise.all([
      getTodayTargets(clientId),
      fetchMealsForRange(clientId, start, end)
    ]);

    if(!targets){ containerEl.innerHTML = ''; return; }

    const eaten = sumMeals(meals);
    const remaining = (targets.calories || 0) - eaten.calories;
    const over = remaining < 0;
    const closeToGoal = !over && Math.abs(remaining) < (targets.calories * 0.10);
    const remClass = over ? 'over' : closeToGoal ? 'good' : '';

    const today = new Date().toLocaleDateString('fr-FR', {weekday:'long', day:'numeric', month:'long'});

    function bar(name, colorKey, current, target){
      const status = statusFor(current, target);
      const pct = target ? (current / target) * 100 : 0;
      const pctDisplay = target ? Math.round(pct) : 0;
      const width = Math.min(100, pct);
      return `
        <div class="mp-bar-row" data-color="${colorKey}" data-status="${status}">
          <div class="mp-bar-label">
            <span class="mp-bar-name">${name}</span>
            <span class="mp-bar-vals"><b>${Math.round(current)}</b> / ${target}g<span class="mp-pct">${pctDisplay}%</span></span>
          </div>
          <div class="mp-bar-track">
            <div class="mp-bar-fill" style="width:${width}%"></div>
          </div>
        </div>
      `;
    }

    containerEl.innerHTML = `
      <div class="mp-card">
        <div class="mp-header">
          <div class="mp-title">Progression du jour</div>
          <div class="mp-day-stamp">${esc(today)}</div>
        </div>
        <div class="mp-cal-big">
          <span class="mp-cal-current">${Math.round(eaten.calories)}</span>
          <span class="mp-cal-target">/ ${targets.calories} kcal</span>
          <span class="mp-cal-remaining ${remClass}">${over ? '+' : ''}${Math.abs(Math.round(remaining))} ${over ? 'kcal au-dessus' : 'kcal restant'}</span>
        </div>
        ${bar('Protéines','protein',eaten.protein,targets.protein)}
        ${bar('Glucides','carbs',eaten.carbs,targets.carbs)}
        ${bar('Lipides','fat',eaten.fat,targets.fat)}
      </div>
    `;
  };

  // ═══════════════════════════════════════════════════════
  // COACH — Weekly Macro Adherence Heatmap
  // ═══════════════════════════════════════════════════════
  window.macroAdherenceRender = async function(clientId, containerEl){
    if(!containerEl || !clientId) return;
    containerEl.innerHTML = '<div class="ma-card"><div class="ma-title">📊 Adherence 7 jours</div><div class="ma-empty">Chargement…</div></div>';

    const sevenDaysAgo = new Date(); sevenDaysAgo.setDate(sevenDaysAgo.getDate()-6); sevenDaysAgo.setHours(0,0,0,0);

    const [goal, meals, sessionDays, overrides] = await Promise.all([
      fetchClientGoal(clientId),
      fetchMealsForRange(clientId, sevenDaysAgo.toISOString(), null),
      fetchSessionDaysLastWeek(clientId),
      fetchOverridesLastWeek(clientId)
    ]);

    if(!goal){
      containerEl.innerHTML = '<div class="ma-card"><div class="ma-title">📊 Adherence 7 jours</div><div class="ma-empty">Pas d\'objectifs définis pour ce client.</div></div>';
      return;
    }

    const trainingDays = goal.training_days || [];
    const days = [];

    for(let i = 6; i >= 0; i--){
      const d = new Date(); d.setDate(d.getDate()-i); d.setHours(0,0,0,0);
      const dateStr = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
      const dayKey = DAY_KEYS[d.getDay()];

      // Resolve day type using the exact same logic as getTodayDayType
      let dayType;
      if(overrides[dateStr]) dayType = overrides[dateStr];
      else if(sessionDays.has(d.toDateString())) dayType = 'training';
      else dayType = trainingDays.includes(dayKey) ? 'training' : 'rest';

      const prefix = dayType === 'training' ? 'training_day_' : 'rest_day_';
      const tgt = {
        cal: goal[prefix+'calories'] ?? goal.target_calories ?? goal.calories ?? 0,
        p:   goal[prefix+'protein']  ?? goal.target_protein  ?? goal.protein  ?? 0,
        c:   goal[prefix+'carbs']    ?? goal.target_carbs    ?? goal.carbs    ?? 0,
        f:   goal[prefix+'fat']      ?? goal.target_fat      ?? goal.fat      ?? 0
      };

      const dayMeals = meals.filter(m => {
        const md = new Date(m.created_at); md.setHours(0,0,0,0);
        return md.getTime() === d.getTime();
      });
      const actual = sumMeals(dayMeals);

      days.push({
        date: d,
        dayKey,
        dayType,
        target: tgt,
        actual: {cal: actual.calories, p: actual.protein, c: actual.carbs, f: actual.fat}
      });
    }

    // Hit counts
    let hitCal=0, hitP=0, hitC=0, hitF=0;
    days.forEach(d => {
      if(adherenceStatusFor(d.actual.cal, d.target.cal) === 'hit') hitCal++;
      if(adherenceStatusFor(d.actual.p,   d.target.p)   === 'hit') hitP++;
      if(adherenceStatusFor(d.actual.c,   d.target.c)   === 'hit') hitC++;
      if(adherenceStatusFor(d.actual.f,   d.target.f)   === 'hit') hitF++;
    });

    const daysWithData = days.filter(d => d.actual.cal > 0).length;

    function cell(actual, target){
      const status = adherenceStatusFor(actual, target);
      const pct = target ? Math.round((actual/target)*100) : 0;
      const tooltip = `${Math.round(actual)}/${target} · ${pct}%`;
      const display = status === 'no-data' ? '–' : pct + '%';
      return `<div class="ma-cell ${status}" title="${tooltip}">${display}</div>`;
    }

    function statClass(n){
      if(n >= 5) return 'good';
      if(n >= 3) return 'ok';
      return 'bad';
    }

    containerEl.innerHTML = `
      <div class="ma-card">
        <div class="ma-title">📊 Adherence 7 jours</div>
        <div class="ma-grid">
          <div></div>
          ${days.map(d => `<div class="ma-day-header ${d.dayType}">${DAY_LABEL_SHORT[d.dayKey]}<b>${d.date.getDate()}</b></div>`).join('')}

          <div class="ma-row-label">Cal</div>
          ${days.map(d => cell(d.actual.cal, d.target.cal)).join('')}

          <div class="ma-row-label">Prot</div>
          ${days.map(d => cell(d.actual.p, d.target.p)).join('')}

          <div class="ma-row-label">Carb</div>
          ${days.map(d => cell(d.actual.c, d.target.c)).join('')}

          <div class="ma-row-label">Lip</div>
          ${days.map(d => cell(d.actual.f, d.target.f)).join('')}
        </div>
        <div class="ma-summary">
          <div class="ma-stat">
            <div class="ma-stat-num ${statClass(hitCal)}">${hitCal}<span>/7</span></div>
            <div class="ma-stat-label">Calories</div>
          </div>
          <div class="ma-stat">
            <div class="ma-stat-num ${statClass(hitP)}">${hitP}<span>/7</span></div>
            <div class="ma-stat-label">Protéines</div>
          </div>
          <div class="ma-stat">
            <div class="ma-stat-num ${statClass(hitC)}">${hitC}<span>/7</span></div>
            <div class="ma-stat-label">Glucides</div>
          </div>
          <div class="ma-stat">
            <div class="ma-stat-num ${statClass(hitF)}">${hitF}<span>/7</span></div>
            <div class="ma-stat-label">Lipides</div>
          </div>
        </div>
        ${daysWithData === 0 ? '<div class="ma-empty" style="margin-top:14px;padding:10px">Aucun repas loggé cette semaine.</div>' : ''}
      </div>
    `;
  };

  // ─── Auto-refresh on events ───
  window.addEventListener('dayTypeChanged', (e) => {
    const cid = e.detail?.clientId;
    if(!cid) return;
    document.querySelectorAll('[data-macro-progress="1"]').forEach(el => {
      if(el.dataset.clientId === cid) macroProgressRender(cid, el);
    });
  });

  window.addEventListener('mealLogged', (e) => {
    const cid = e.detail?.clientId;
    if(!cid) return;
    document.querySelectorAll('[data-macro-progress="1"]').forEach(el => {
      if(el.dataset.clientId === cid) macroProgressRender(cid, el);
    });
  });

  window.addEventListener('macroGoalsUpdated', (e) => {
    const cid = e.detail?.clientId;
    if(!cid) return;
    document.querySelectorAll('[data-macro-progress="1"]').forEach(el => {
      if(el.dataset.clientId === cid) macroProgressRender(cid, el);
    });
  });

  console.log('[Phase 7.5] Macro enhancements loaded — macroProgressRender, macroAdherenceRender exposed.');
})();
